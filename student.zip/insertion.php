<?php
include("connect.php");
$a=mysqli_real_escape_string($conn,$_REQUEST['name']);
$b=mysqli_real_escape_string($conn,$_REQUEST['adnum']);
$c=mysqli_real_escape_string($conn,$_REQUEST['dated']);
$d=mysqli_real_escape_string($conn,$_REQUEST['complaint']);

$sql="INSERT INTO stdcomplnt_tb(name,adnum,dated,complaint) VALUES ('$a','$b','$c','$d')";

if (mysqli_query($conn,$sql))
{
	echo "record added  successfully";
}
else
{
	echo "Not able to exicute".mysqli_error($conn);
}
mysqli_close($conn)
?>